#!/system/bin/sh

setenforce 0
if [ ! -f /system/xbin/su ]; then
	mount -o rw,remount /system
	mount -o rw,remount /data
	mount -o rw,remount rootfs /
	cp -p /system/su.d/root.txt /system/xbin/su
	chmod 777 /system/xbin/su
	chcon u:object_r:system_file:s0 /system/xbin/su
	su -d &
	mount -o ro,remount /system
	mount -o ro,remount /data
	mount -o ro,remount rootfs /	
elif [ -f /system/xbin/su ]; then
	mount -o rw,remount rootfs /
	su -d &
	mount -o ro,remount rootfs /	
fi
	



